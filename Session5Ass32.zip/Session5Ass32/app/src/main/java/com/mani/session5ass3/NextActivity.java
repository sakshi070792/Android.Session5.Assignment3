package com.mani.session5ass3;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by sakshi.banger on 07-09-2016.
 */
public class NextActivity extends Activity {
    TextView tvmentor;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nextactivity_main);
        tvmentor = (TextView) findViewById(R.id.tvmentor);
        savedInstanceState = getIntent().getExtras();
        String mentor = savedInstanceState.getString("Android");

        String mentor1 = savedInstanceState.getString("BIGDATA");
        String mentor2 = savedInstanceState.getString("HADOOP");
        String mentor3 = savedInstanceState.getString("JAVA");
        if (mentor != null) {
            tvmentor.setText(mentor);
        }
        else if(mentor1!=null){
            tvmentor.setText(mentor1);
        }
        else if(mentor2!=null){
            tvmentor.setText(mentor2);
        }
        else if(mentor3!=null){
            tvmentor.setText(mentor3);
        }



    }
}
