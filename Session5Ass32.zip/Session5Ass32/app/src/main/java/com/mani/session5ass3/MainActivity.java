package com.mani.session5ass3;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity implements View.OnClickListener {
    Button btandroid,btbigdata,btjava,bthadoop;
    Intent i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btandroid=(Button)findViewById(R.id.btandroid);
        btbigdata=(Button)findViewById(R.id.btbigdata);
        bthadoop=(Button)findViewById(R.id.bthadoop);
        btjava=(Button)findViewById(R.id.btjava);
        btandroid.setOnClickListener(this);
        btjava.setOnClickListener(this);
        bthadoop.setOnClickListener(this);
        btbigdata.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btandroid:
                 i=new Intent(this,NextActivity.class);
                i.putExtra("Android","Manikantha");
                startActivity(i);
                break;
            case R.id.btbigdata:
                 i=new Intent(this,NextActivity.class);
                i.putExtra("BIGDATA","RAJA");
                startActivity(i);
                break;
            case R.id.bthadoop:
                i=new Intent(this,NextActivity.class);
                i.putExtra("HADOOP","Payal");
                startActivity(i);
                break;
            case R.id.btjava:
                 i=new Intent(this,NextActivity.class);
                i.putExtra("JAVA","Mahi");
                startActivity(i);
                break;

        }

    }
}
